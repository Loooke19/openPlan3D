#!/bin/bash
cd /workspace/codex-cutlayer-run
codex exec -m gpt-6.1-sol -c model_reasoning_effort=high -s workspace-write -c sandbox_workspace_write.network_access=true --add-dir /workspace --skip-git-repo-check -C /workspace/codex-cutlayer-run "按 /workspace/codex-cutlayer-run/task.md 执行（dev 端口 5322，playwright 端口 4192）。上一次运行因额度中断，工作区已有未提交的部分改动：先看 git status / git diff，在现有改动基础上继续，不要从头重来。测试从简：guard + 相关专项测试 + P1 前后截图。完成后写 /workspace/codex-cutlayer-run/report.md。" </dev/null > /workspace/codex-cutlayer-run/run2.log 2>&1
echo "cutlayer exit $? $(date +%H:%M)" >> /workspace/codex-chain.status
