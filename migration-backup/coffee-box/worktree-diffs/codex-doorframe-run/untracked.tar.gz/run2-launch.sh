#!/bin/bash
cd /workspace/codex-doorframe-run
codex exec -m gpt-6.1-sol -c model_reasoning_effort=high -s workspace-write -c sandbox_workspace_write.network_access=true --add-dir /workspace --skip-git-repo-check -C /workspace/codex-doorframe-run "按 /workspace/codex-doorframe-run/task.md 执行（dev 端口 5321，playwright 端口 4191）。上一次运行因额度中断，工作区已有未提交的部分改动：先看 git status / git diff，在现有改动基础上继续，不要从头重来。测试从简：guard + 相关专项测试 + P1 前后截图。完成后写 /workspace/codex-doorframe-run/report.md。" </dev/null > /workspace/codex-doorframe-run/run2.log 2>&1
echo "doorframe exit $? $(date +%H:%M)" >> /workspace/codex-chain.status
