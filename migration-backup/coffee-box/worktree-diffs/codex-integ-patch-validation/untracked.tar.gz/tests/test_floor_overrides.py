import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import draw_rooms
import floor_nav as nav
import floor_overrides as overrides
from pdf_building import _room_faces
from test_floor_nav import two_rooms, rooms_off_corridor


class FloorOverrideTests(unittest.TestCase):
    def test_merge_retains_named_id_and_untouched_room(self):
        floor = rooms_off_corridor()
        old = copy.deepcopy(floor["rooms"])
        overrides.apply(floor, [], {"walls_remove": [{"x": 150, "y": 300, "tol": 1}]})
        room_b = next(r for r in floor["rooms"] if r["id"] == "room-b")
        self.assertEqual(room_b["name"], old[1]["name"])
        self.assertEqual(set(room_b["walls"]), set(old[1]["walls"]))
        self.assertEqual(len({r["id"] for r in floor["rooms"]}), len(floor["rooms"]))

    def test_split_keeps_one_manual_name_and_unique_ids(self):
        floor = two_rooms()
        floor["rooms"][0].update(name="手工诊室", nameSource="manual", displayName="改过的名称")
        overrides.apply(floor, [], {"walls_add": [{"start": {"x": 200, "y": 0},
                                                  "end": {"x": 200, "y": 300}}]})
        named = [r for r in floor["rooms"] if r.get("name") == "手工诊室"]
        self.assertEqual(len(named), 1)
        self.assertEqual(named[0]["id"], "room-a")
        self.assertEqual(named[0]["displayName"], "改过的名称")
        self.assertEqual(len(floor["rooms"]), 3)

    def test_void_stays_blocked_even_with_a_door_and_footprint(self):
        floor = two_rooms()
        floor["footprint"] = [{"x": 0, "y": 0}, {"x": 800, "y": 0},
                              {"x": 800, "y": 300}, {"x": 0, "y": 300}]
        overrides.apply(floor, [], {"rooms": [{"x": 150, "y": 150, "name": "门厅上空",
                                               "floorOpening": True, "floorTexture": "none"}]})
        grid = nav.build_grid(floor)
        poly = _room_faces(floor)["room-a"]
        inside = [grid.walkable(c, r) for r in range(grid.rows) for c in range(grid.cols)
                  if nav._point_in_polygon(*grid.center(c, r), poly)]
        self.assertTrue(inside)
        self.assertFalse(any(inside))
        self.assertNotIn("room-a", {d["id"] for d in grid.destinations})

    def test_drawn_geometry_and_manual_door_survive(self):
        floor = two_rooms()
        rect = [{"x": 1000, "y": 0}, {"x": 1300, "y": 0},
                {"x": 1300, "y": 300}, {"x": 1000, "y": 300}]
        room = draw_rooms.add_drawn_room(floor, rect, "手工房间", key="stable")
        drawn = copy.deepcopy(room)
        walls = [copy.deepcopy(w) for w in floor["walls"] if w.get("drawn")]
        doors = copy.deepcopy(floor["doors"])
        overrides.apply(floor, [], {"walls_remove_box": [{"x0": 999, "y0": -1, "x1": 1301, "y1": 301}],
                                    "walls_add": [{"start": {"x": 200, "y": 0}, "end": {"x": 200, "y": 300}}]})
        self.assertIn(drawn, floor["rooms"])
        self.assertTrue(all(w in floor["walls"] for w in walls))
        self.assertEqual(floor["doors"], doors)
        self.assertEqual(len([r for r in floor["rooms"] if r.get("drawn")]), 1)

    def test_placeholders_are_never_searchable(self):
        for name in ["", None, "房间 54", "房间54", "Room 9", "room9"]:
            self.assertFalse(nav.is_destination(name))
        self.assertTrue(nav.is_destination("办公室"))

    def test_reimport_uses_previous_ids(self):
        edit = {"walls_add": [{"start": {"x": 200, "y": 0}, "end": {"x": 200, "y": 300}}]}
        first = two_rooms()
        overrides.apply(first, [], edit)
        again = two_rooms()
        overrides.apply(again, [], edit, previous_floor=first)
        self.assertEqual({r["id"]: set(r["walls"]) for r in first["rooms"]},
                         {r["id"]: set(r["walls"]) for r in again["rooms"]})

    def test_manual_door_host_is_kept(self):
        floor = two_rooms()
        floor["doors"][0]["drawn"] = True
        before = copy.deepcopy(floor)
        overrides.apply(floor, [], {"walls_remove": [{"x": 400, "y": 150, "tol": 1}]})
        self.assertEqual(floor, before)

    def test_small_manual_fragment_wins_a_merge(self):
        floor = two_rooms()
        for wall in floor["walls"]:
            for point in [wall["start"], wall["end"]]:
                if point["x"] == 800:
                    point["x"] = 1600
        floor["rooms"][0].update(name="人工名字", nameSource="manual")
        overrides.apply(floor, [], {"walls_remove": [{"x": 400, "y": 150, "tol": 1}]})
        self.assertEqual(len(floor["rooms"]), 1)
        self.assertEqual(floor["rooms"][0]["id"], "room-a")
        self.assertEqual(floor["rooms"][0]["name"], "人工名字")


if __name__ == "__main__":
    unittest.main()
