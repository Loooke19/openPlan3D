import { chromium } from 'playwright';
const id=process.argv[2];
const URL=`http://127.0.0.1:5277/nav?projectUrl=http%3A%2F%2F127.0.0.1%3A8878%2Fapi%2Fprojects%2F${id}.json&id=${id}&apiOrigin=http%3A%2F%2F127.0.0.1%3A8878&filesUrl=http%3A%2F%2F127.0.0.1%3A8878%2Ffiles&floor=floor-0`;
const b=await chromium.launch({headless:false,executablePath:'/opt/google/chrome/chrome'}); const p=await b.newPage({viewport:{width:1440,height:900}});
const t0=Date.now(); await p.goto(URL,{waitUntil:'commit'});
for(let i=0;i<25;i++){ const r=await Promise.race([p.evaluate(()=>document.querySelectorAll('button.pp-field').length+'/'+document.body.innerText.length),new Promise(r=>setTimeout(()=>r('HANG'),8000))]); console.log(Math.round((Date.now()-t0)/1000),r); await p.waitForTimeout(3000);}
process.exit(0);
