import { chromium } from 'playwright';
const id='b1f10000000000000000000000000001';
const URL=`http://127.0.0.1:5277/nav?projectUrl=http%3A%2F%2F127.0.0.1%3A8878%2Fapi%2Fprojects%2F${id}.json&id=${id}&apiOrigin=http%3A%2F%2F127.0.0.1%3A8878&filesUrl=http%3A%2F%2F127.0.0.1%3A8878%2Ffiles&floor=floor-0`;
const b=await chromium.launch({headless:false,executablePath:'/opt/google/chrome/chrome'}); const p=await b.newPage({viewport:{width:1440,height:900}});
await p.goto(URL,{waitUntil:'commit'}); await p.waitForTimeout(60000);
console.log((await p.evaluate(()=>document.body.innerText)).slice(0,1500));
console.log(await p.evaluate(()=>[...document.querySelectorAll('button,input,select')].map(e=>e.tagName+':'+(e.getAttribute('aria-label')||e.className||'')+':'+(e.textContent||'').trim().slice(0,20)).slice(0,60).join('\n')));
await p.screenshot({path:'/tmp/p3.png'}); process.exit(0);
