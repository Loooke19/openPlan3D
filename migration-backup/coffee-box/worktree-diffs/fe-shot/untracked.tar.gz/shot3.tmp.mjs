import { chromium } from 'playwright';
const id='b1f10000000000000000000000000001';
const URL=`http://127.0.0.1:5277/nav?projectUrl=http%3A%2F%2F127.0.0.1%3A8878%2Fapi%2Fprojects%2F${id}.json&id=${id}&apiOrigin=http%3A%2F%2F127.0.0.1%3A8878&filesUrl=http%3A%2F%2F127.0.0.1%3A8878%2Ffiles&floor=floor-0`;
const O='/workspace/zone-audit/shots/';
const b=await chromium.launch({headless:false,executablePath:'/opt/google/chrome/chrome'});
const p=await b.newPage({viewport:{width:1440,height:900},deviceScaleFactor:2});
p.setDefaultTimeout(1200000);
await p.goto(URL,{waitUntil:'commit'});
await p.waitForSelector('button.pp-field',{state:'attached'}); console.log('loaded',new Date());
async function pick(label,q,floor){ await p.locator(`button.pp-field[aria-label="${label}"]`).click(); await p.fill('input[aria-label="搜索地点"]',q); await p.waitForTimeout(1500);
  await p.locator('.pp-item',{hasText:q}).filter({hasText:floor}).first().click(); console.log('picked',q,new Date()); }
await pick('起点','挂号','1F'); await pick('终点','体检窗口','3F');
await p.waitForTimeout(20000);
await p.locator('button',{hasText:'立体 3D'}).click();
await p.waitForSelector('canvas[data-plan3d-canvas="true"]'); await p.waitForTimeout(60000);
await p.screenshot({path:O+'P1-route-3d-overview.png',timeout:1200000}); console.log('shot1',new Date());
console.log((await p.locator('.side').innerText()).slice(0,800));
const seg=p.locator('[aria-label="分段"] button'); const n=await seg.count(); console.log('segs',n,await seg.allInnerTexts());
if(n>1){ await seg.nth(1).click(); await p.waitForTimeout(40000); }
await p.screenshot({path:O+'P1-route-stair-transfer.png',timeout:1200000}); console.log('shot2',new Date());
process.exit(0);
