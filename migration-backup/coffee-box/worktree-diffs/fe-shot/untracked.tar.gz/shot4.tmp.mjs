import { chromium } from 'playwright';
const id='b1f10000000000000000000000000001';
const URL=`http://127.0.0.1:5277/nav?projectUrl=http%3A%2F%2F127.0.0.1%3A8878%2Fapi%2Fprojects%2F${id}.json&id=${id}&apiOrigin=http%3A%2F%2F127.0.0.1%3A8878&filesUrl=http%3A%2F%2F127.0.0.1%3A8878%2Ffiles&floor=floor-0`;
const O='/workspace/zone-audit/shots/';
const b=await chromium.launch({headless:false,executablePath:'/opt/google/chrome/chrome'});
const p=await b.newPage({viewport:{width:1440,height:900},deviceScaleFactor:2}); p.setDefaultTimeout(600000);
await p.goto(URL,{waitUntil:'commit'});
await p.waitForSelector('select[aria-label="起点"]'); await p.waitForTimeout(30000);
const val=async(lab,t)=>p.locator(`select[aria-label="${lab}"] option`,{hasText:t}).first().getAttribute('value');
await p.selectOption('select[aria-label="起点"]', await val('起点','1F · 挂号'));
await p.selectOption('select[aria-label="终点"]', await val('终点','3F · 体检窗口'));
await p.waitForTimeout(40000);
await p.screenshot({path:O+'P1-route-3d-overview.png'}); console.log('shot1');
console.log((await p.evaluate(()=>document.querySelector('aside')?.innerText||'')).slice(0,600));
const segs=p.locator('[aria-label="分段"] button'); const n=await segs.count(); console.log('segs',n,await segs.allInnerTexts());
if(n>1){ await segs.nth(n-1).click(); await p.waitForTimeout(30000); }
await p.screenshot({path:O+'P1-route-stair-transfer.png'}); console.log('shot2');
process.exit(0);
